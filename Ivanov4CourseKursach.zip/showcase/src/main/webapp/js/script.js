window.addEventListener('load', function () {
    
    let isNavOpen = false;
   document.querySelector('.burger').addEventListener('click', function () {

       console.log(document.querySelector('nav').style.display);
       document.querySelector('nav').style.display = isNavOpen ? 'none' :'block';
       isNavOpen = isNavOpen ? false : true;
   })
     
    
});