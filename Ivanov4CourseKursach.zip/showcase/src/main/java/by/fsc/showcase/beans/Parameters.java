package by.fsc.showcase.beans;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name ="parameters_tab" )
@Data
public class Parameters {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;

    @Column
    private String keyVal;

    @Column
    private String valueVal;

    @Column
    private String priceVal;

    @ManyToOne
    @JoinColumn(name="item_id", nullable=false)
    private Item item;
}
