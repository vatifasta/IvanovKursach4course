package by.fsc.showcase.filter;

import by.fsc.showcase.beans.Category;
import by.fsc.showcase.repsitories.CategoryRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.transaction.Transactional;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
@Order(1)
@Slf4j
public class MenuFilter implements Filter {

    @Autowired
    CategoryRepository categoryRepository;

    @Override
    @Transactional
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        List<Category> categoryList = categoryRepository.findAll();
        List<Category> categoriesForDelete = categoryList
                .stream()
                .filter(category -> category.getItems().size() == 0)
                .collect(Collectors.toList());

        categoryRepository.deleteAll(categoriesForDelete);

        servletRequest.setAttribute("categories"
                , categoryList
                .stream()
                .filter(category -> category.getItems().size() != 0)
                .collect(Collectors.toList()));
        log.info("FILTER WORKING: DATA " + categoryList.size());
        filterChain.doFilter(servletRequest, servletResponse);
    }
}
