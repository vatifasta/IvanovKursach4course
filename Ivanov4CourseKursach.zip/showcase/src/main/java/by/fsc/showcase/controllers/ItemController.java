package by.fsc.showcase.controllers;

import by.fsc.showcase.beans.Category;
import by.fsc.showcase.beans.Item;
import by.fsc.showcase.beans.Parameters;
import by.fsc.showcase.beans.PicturePath;
import by.fsc.showcase.repsitories.CategoryRepository;
import by.fsc.showcase.repsitories.ItemRepository;
import by.fsc.showcase.repsitories.ParametersRepository;
import by.fsc.showcase.repsitories.PicturePthRepository;
import by.fsc.showcase.service.ItemService;
import by.fsc.showcase.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;
import javax.transaction.Transactional;
import java.io.IOException;
import java.util.Date;

@Controller
public class ItemController {

    @Autowired
    private ItemService itemService;

    @Autowired
    private PicturePthRepository picturePthRepository;

    @Autowired
    private ParametersRepository parametersRepository;

    @Autowired
    private ItemRepository itemRepository;

    @Value("${count.per_page}")
    int countPerPage;

    @Autowired
    private CategoryRepository categoryRepository;

    @RequestMapping(path = "/items", method = RequestMethod.GET)
    public String getItems(ModelMap model, @RequestParam(defaultValue = "0", required = false) int page, @RequestParam(defaultValue = "none", required = false) String category) {
        if ("none".equals(category)) {
            model.addAttribute("items", itemService.getAllItems(page));
        } else {
            model.addAttribute("items", itemRepository.getByCategory(categoryRepository.getByName(category).get(), PageRequest.of(page, countPerPage)));
        }
        model.addAttribute("category", category);
        return "items_temp";
    }


    @GetMapping(path = "/admin/items/remove/{id}")
    public String removeItem(@PathVariable int id) throws IOException {
        itemService.remove(id);
        FileUtil.removeFile(id);
        return "redirect:/items";
    }


    @GetMapping(path = "/items/{id}")
    public String getById(@PathVariable int id, ModelMap model) {
        model.addAttribute("item", itemService.getById(id));
        return "item_temp";
    }


    @GetMapping(path = "admin/items/{id}/edit")
    public String getByIdEdit(@PathVariable int id, ModelMap model) {
        model.addAttribute("item", itemService.getById(id));
        return "edit_temp";
    }


    @Transactional
    @PostMapping(path = "admin/items/add")
    public String addItem(Item item, HttpServletRequest request) throws IOException, ServletException {
        item.setDate(new Date());
        Category category = item.getCategory();
        if (category.getName() != null && !category.getName().equals("")) {
            Category category1 = new Category();
            category1.setName(category.getName());
            item.setCategory( categoryRepository.getByName(category.getName()).orElse(category1));
        }
        itemService.save(item);
        Part part = request.getPart("file");
        FileUtil.processFile(item.getId(), part);
        return "redirect:/items/" + item.getId();
    }

    @PostMapping(path = "admin/items/add/{id}")
    public String addItem(HttpServletRequest request, @PathVariable Integer id) throws IOException, ServletException {
        Item item = itemService.getById(id);
        request.getParts().forEach(part -> {
                    try {
                        FileUtil.processFile(part.getSubmittedFileName(), part);
                        PicturePath picturePath = new PicturePath();
                        picturePath.setPicName(part.getSubmittedFileName());
                        picturePath.setItem(item);
                        picturePthRepository.save(picturePath);
                    } catch (IOException e) {

                    }
                }
        );
        return "redirect:/items/" + id;
    }


    @Transactional
    @PostMapping(path = "admin/items/update/{id}")
    public String updateItem(@PathVariable int id, Item item, HttpServletRequest request) throws IOException, ServletException {

        Category category = item.getCategory();
        if (category.getName() != null && !category.getName().equals("")) {
            Category category1 = new Category();
            category1.setName(category.getName());
            item.setCategory( categoryRepository.getByName(category.getName()).orElse(category1));
        }
        Part part = request.getPart("file");
        if (part.getSize() != 0) {
            FileUtil.removeFile(id);
            FileUtil.processFile(item.getId(), part);
        }

        Item item1 = itemService.getById(id);
        item1.setName(item.getName());
        item1.setDescription(item.getDescription());
        item1.setDate(new Date());
        itemService.update(item);
        return "redirect:/admin/items/" + item.getId() + "/edit";
    }

    @PostMapping(path = "/admin/parameters/add")
    public String addParameter(Parameters parameters, Integer itemId) {
        Item item = new Item();
        item.setId(itemId);
        parameters.setItem(item);
        parametersRepository.save(parameters);
        return "redirect:/admin/items/" + itemId+"/edit";
    }

    @GetMapping(path = "admin/parameters/remove/{itemId}/{id}")
    public String removeParameter(@PathVariable Integer id, @PathVariable Integer itemId) {
        parametersRepository.deleteById(id);
        return "redirect:/admin/items/" + itemId+"/edit";
    }
}