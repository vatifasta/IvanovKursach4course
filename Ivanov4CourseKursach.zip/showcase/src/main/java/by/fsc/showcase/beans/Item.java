package by.fsc.showcase.beans;


import lombok.Data;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@Entity(name = "items")
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column
    private String name;

    @Column(length = 150000)
    private String description;

    @Column
    private Date date;

    @OneToMany(mappedBy = "item")
    private List<PicturePath> picturePaths = new ArrayList<>();

    @OneToMany(mappedBy = "item")
    private List<Parameters> parameters = new ArrayList<>();

    @Column
    private String name2;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

}
