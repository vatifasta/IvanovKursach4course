package by.fsc.showcase.repsitories;

import by.fsc.showcase.beans.PicturePath;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PicturePthRepository extends JpaRepository<PicturePath, Integer> {
}
