package by.fsc.showcase.repsitories;

import by.fsc.showcase.beans.Parameters;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametersRepository extends JpaRepository<Parameters,Integer> {
}
